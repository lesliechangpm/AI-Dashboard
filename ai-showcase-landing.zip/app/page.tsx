import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Bot, Brain, MessageSquare, Zap, ExternalLink, Mail, Github, Twitter } from "lucide-react"

export default function HomePage() {
  // Sample AI agents data - replace with your actual proof of concepts
  const aiAgents = [
    {
      id: 1,
      name: "Smart Document Analyzer",
      description:
        "AI-powered document processing that extracts key insights and summarizes complex information automatically.",
      icon: <Bot className="h-8 w-8" />,
      status: "Active",
      link: "#",
      tags: ["NLP", "Document Processing"],
    },
    {
      id: 2,
      name: "Intelligent Chat Assistant",
      description:
        "Conversational AI that provides contextual support and answers questions with human-like understanding.",
      icon: <MessageSquare className="h-8 w-8" />,
      status: "Beta",
      link: "#",
      tags: ["Conversational AI", "Support"],
    },
    {
      id: 3,
      name: "Predictive Analytics Engine",
      description:
        "Machine learning model that forecasts trends and provides actionable business intelligence insights.",
      icon: <Brain className="h-8 w-8" />,
      status: "Active",
      link: "#",
      tags: ["ML", "Analytics"],
    },
    {
      id: 4,
      name: "Automated Content Generator",
      description: "Creative AI that generates high-quality content, from marketing copy to technical documentation.",
      icon: <Zap className="h-8 w-8" />,
      status: "Coming Soon",
      link: "#",
      tags: ["Content Generation", "Creative AI"],
    },
  ]

  return (
    <div className="min-h-screen bg-stone-50">
      {/* Header */}
      <header className="bg-slate-800 text-white sticky top-0 z-50 shadow-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="text-2xl font-bold text-yellow-400">CMG</div>
              <div className="h-6 w-px bg-gray-400"></div>
              <h1 className="text-xl font-semibold">AI Assistants</h1>
            </div>
            <Button className="bg-lime-500 hover:bg-lime-600 text-slate-800 font-medium">
              <Mail className="h-4 w-4 mr-2" />
              Contact Us
            </Button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 px-4 bg-gradient-to-b from-stone-50 to-stone-100">
        <div className="container mx-auto text-center max-w-4xl">
          <h2 className="text-5xl md:text-6xl font-bold text-slate-800 mb-6">CMG AI Assistants</h2>
          <p className="text-xl text-slate-600 mb-8 leading-relaxed max-w-3xl mx-auto">
            Explore our collection of innovative AI solutions designed to transform how you work. Test each proof of
            concept and share your valuable feedback to help us improve.
          </p>
          <div className="flex flex-wrap justify-center gap-3 mb-8">
            <Badge className="bg-teal-600 hover:bg-teal-700 text-white px-4 py-2">Machine Learning</Badge>
            <Badge className="bg-teal-600 hover:bg-teal-700 text-white px-4 py-2">Natural Language Processing</Badge>
            <Badge className="bg-teal-600 hover:bg-teal-700 text-white px-4 py-2">Computer Vision</Badge>
            <Badge className="bg-teal-600 hover:bg-teal-700 text-white px-4 py-2">Automation</Badge>
          </div>
        </div>
      </section>

      {/* AI Agents Showcase */}
      <section className="py-16 px-4 bg-white">
        <div className="container mx-auto max-w-6xl">
          <h3 className="text-3xl font-bold text-slate-800 text-center mb-12">Available Proof of Concepts</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-8">
            {aiAgents.map((agent) => (
              <Card
                key={agent.id}
                className="group hover:shadow-xl transition-all duration-300 border-stone-200 bg-white hover:border-teal-200"
              >
                <CardHeader className="pb-4">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center space-x-4">
                      <div className="p-3 bg-teal-50 rounded-xl text-teal-600 group-hover:bg-teal-600 group-hover:text-white transition-colors">
                        {agent.icon}
                      </div>
                      <div>
                        <CardTitle className="text-xl font-semibold text-slate-800">{agent.name}</CardTitle>
                        <Badge
                          className={
                            agent.status === "Active"
                              ? "bg-lime-500 text-slate-800 mt-2"
                              : agent.status === "Beta"
                                ? "bg-yellow-500 text-slate-800 mt-2"
                                : "bg-stone-200 text-slate-600 mt-2"
                          }
                        >
                          {agent.status}
                        </Badge>
                      </div>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="pb-6">
                  <CardDescription className="text-slate-600 leading-relaxed mb-4 text-base">
                    {agent.description}
                  </CardDescription>
                  <div className="flex flex-wrap gap-2">
                    {agent.tags.map((tag) => (
                      <Badge key={tag} variant="outline" className="text-xs border-teal-200 text-teal-700">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                </CardContent>
                <CardFooter>
                  <Button
                    className={`w-full font-medium transition-all ${
                      agent.status === "Coming Soon"
                        ? "bg-stone-100 text-stone-400 cursor-not-allowed"
                        : "bg-teal-600 hover:bg-teal-700 text-white group-hover:shadow-md"
                    }`}
                    disabled={agent.status === "Coming Soon"}
                  >
                    {agent.status === "Coming Soon" ? "Coming Soon" : "Try It Out"}
                    {agent.status !== "Coming Soon" && <ExternalLink className="h-4 w-4 ml-2" />}
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Feedback Section */}
      <section className="py-20 px-4 bg-stone-100">
        <div className="container mx-auto max-w-2xl">
          <div className="text-center mb-10">
            <h3 className="text-3xl font-bold text-slate-800 mb-4">Share Your Feedback</h3>
            <p className="text-slate-600 text-lg">
              Your insights help us improve our AI solutions. Let us know what you think!
            </p>
          </div>
          <Card className="bg-white border-stone-200 shadow-lg">
            <CardContent className="p-8">
              <form className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label htmlFor="name" className="text-sm font-semibold mb-2 block text-slate-700">
                      Name
                    </label>
                    <Input id="name" placeholder="Your name" className="border-stone-300 focus:border-teal-500" />
                  </div>
                  <div>
                    <label htmlFor="email" className="text-sm font-semibold mb-2 block text-slate-700">
                      Email
                    </label>
                    <Input
                      id="email"
                      type="email"
                      placeholder="your@email.com"
                      className="border-stone-300 focus:border-teal-500"
                    />
                  </div>
                </div>
                <div>
                  <label htmlFor="agent" className="text-sm font-semibold mb-2 block text-slate-700">
                    Which AI agent did you try?
                  </label>
                  <Input
                    id="agent"
                    placeholder="e.g., Smart Document Analyzer"
                    className="border-stone-300 focus:border-teal-500"
                  />
                </div>
                <div>
                  <label htmlFor="feedback" className="text-sm font-semibold mb-2 block text-slate-700">
                    Your Feedback
                  </label>
                  <Textarea
                    id="feedback"
                    placeholder="Tell us about your experience, suggestions for improvement, or any issues you encountered..."
                    rows={4}
                    className="border-stone-300 focus:border-teal-500"
                  />
                </div>
                <Button className="w-full bg-lime-500 hover:bg-lime-600 text-slate-800 font-semibold py-3 text-lg">
                  Submit Feedback
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-slate-800 text-white py-12 px-4">
        <div className="container mx-auto">
          <div className="flex flex-col md:flex-row justify-between items-center space-y-6 md:space-y-0">
            <div className="flex items-center space-x-3">
              <div className="text-2xl font-bold text-yellow-400">CMG</div>
              <div className="h-6 w-px bg-gray-400"></div>
              <span className="font-semibold text-lg">AI Assistants</span>
            </div>
            <div className="flex items-center space-x-4">
              <Button variant="ghost" size="sm" className="text-gray-300 hover:text-white hover:bg-slate-700">
                <Github className="h-5 w-5" />
              </Button>
              <Button variant="ghost" size="sm" className="text-gray-300 hover:text-white hover:bg-slate-700">
                <Twitter className="h-5 w-5" />
              </Button>
              <Button variant="ghost" size="sm" className="text-gray-300 hover:text-white hover:bg-slate-700">
                <Mail className="h-5 w-5" />
              </Button>
            </div>
          </div>
          <div className="mt-8 pt-6 border-t border-slate-700 text-center text-gray-400">
            <p>&copy; 2025 CMG AI Assistants. Built for collecting feedback on AI proof of concepts.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
